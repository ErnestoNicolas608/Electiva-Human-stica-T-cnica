---
name: Cyber Blue Operations
colors:
  surface: '#10131b'
  surface-dim: '#10131b'
  surface-bright: '#363942'
  surface-container-lowest: '#0b0e16'
  surface-container-low: '#181c23'
  surface-container: '#1c2027'
  surface-container-high: '#272a32'
  surface-container-highest: '#31353d'
  on-surface: '#e0e2ed'
  on-surface-variant: '#c1c6d7'
  inverse-surface: '#e0e2ed'
  inverse-on-surface: '#2d3039'
  outline: '#8b90a0'
  outline-variant: '#414754'
  surface-tint: '#adc7ff'
  primary: '#adc7ff'
  on-primary: '#002e68'
  primary-container: '#4a8eff'
  on-primary-container: '#00285b'
  inverse-primary: '#005bc0'
  secondary: '#bdf4ff'
  on-secondary: '#00363d'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#ffb695'
  on-tertiary: '#571e00'
  tertiary-container: '#ef6719'
  on-tertiary-container: '#4c1a00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7c2e00'
  background: '#10131b'
  on-background: '#e0e2ed'
  surface-variant: '#31353d'
  surface-base: '#050505'
  surface-panel: '#131313'
  status-success: '#00E5FF'
  status-error: '#FF3B3B'
  status-warning: '#FFD600'
  terminal-cyan: '#00F0FF'
typography:
  display-lg:
    fontFamily: JetBrains Mono
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -1px
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.5px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 1.5px
  mono-data:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for high-stakes network monitoring and cybersecurity oversight. It evokes the atmosphere of a professional Network Operations Center (NOC) through a "Cyber-Tech" aesthetic. The visual narrative balances institutional authority with high-performance technical precision, moving away from "hacker" tropes toward a sophisticated, industrial-grade software feel.

The style utilizes **Glassmorphism** and **Modern Minimalism** to manage high data density. Surfaces are deep and atmospheric, using semi-transparent layers to create a sense of digital depth. The emotional response is one of calm control, clarity, and rapid technical insight under pressure.

## Colors

The palette is rooted in a "Deep Dark" environment to maximize contrast and reduce eye strain during long monitoring sessions. 

- **Primary (Technical Blue):** Used for primary actions, active navigation states, and core branding. It represents the "standard operating" state.
- **Secondary (Vibrant Electric Blue/Cyan):** Reserved for "Healthy" status, successful pings, and active data streams.
- **Tertiary (Alert Red):** Specifically for critical breaches, downed nodes, or unauthorized access attempts.
- **Neutral:** A scale of deep grays and blacks used to establish hierarchy through surface luminance rather than color. 

All accent colors should be applied with high saturation to pop against the #050505 background.

## Typography

The typography strategy employs a dual-font system to separate narrative content from technical data.

- **JetBrains Mono** is the "Technical Voice," used for headlines, status labels, and all numerical data. It ensures that IP addresses and log timestamps remain perfectly legible and aligned.
- **Inter** is the "Functional Voice," used for body text, descriptions, and tooltips to provide a modern, highly readable interface for long-form reports.

Always use Monospaced variants for data tables and logs to prevent "jumping" characters when values update in real-time.

## Layout & Spacing

This design system utilizes a **Fluid Grid** model based on a 4px baseline.

- **Dashboard Layout:** A 12-column grid on desktop, transitioning to a single column on mobile. 
- **Density:** High-density spacing is mandatory. Use 8px (2 units) for internal component spacing and 16px (4 units) for gaps between major layout modules.
- **The "Grid" Layer:** A subtle 32px repeating square grid pattern should be visible in the background canvas at 3% opacity to reinforce the "Engineering" feel.

## Elevation & Depth

Depth is expressed through **translucency, luminosity, and inner glows** rather than traditional drop shadows.

1.  **Canvas:** The base layer (#050505) with the subtle grid pattern.
2.  **Panels:** Semi-transparent surfaces (80% opacity) using `#131313` with a `20px` backdrop blur. 
3.  **Borders:** Use 1px solid borders. For inactive elements, use `rgba(255, 255, 255, 0.08)`. 
4.  **Active Glow:** Active or Critical states use a `0px 0px 10px` outer glow (drop shadow with 0 spread) matching the Primary Blue or Status color at 30% opacity.

## Shapes

Shapes are "Soft" but disciplined, leaning toward a utilitarian, hardware-inspired aesthetic. 

A 4px (`0.25rem`) base radius is used for cards and buttons. This maintains a professional, technical appearance. Avoid "Pill" shapes for functional buttons; keep them rectangular with subtle rounding to match the geometric nature of network diagrams and technical schematics.

## Components

- **Buttons:** Primary buttons use a solid Technical Blue fill with white text. Secondary buttons use a transparent background with a 1px Technical Blue border. All buttons should have a `hover` state with an increased outer glow.
- **Status Chips:** Small, monospaced text indicators with a leading "indicator dot." The dot should have a CSS `pulse` animation if the status is "Live."
- **Data Cards:** Cards must feature a "Header" section with a 1px bottom border. Include a "Terminal" style header (e.g., `> [SYS_LOG_01]`) in the top-left corner using `label-caps`.
- **Input Fields:** Ghost-style inputs with a 1px bottom border only. On focus, the border transitions to Technical Blue with a subtle glow.
- **Minimalist Charts:** Sparklines and area charts should use a single stroke color (Electric Blue/Cyan) with a 10% opacity gradient fill beneath the line.
- **Alert Banner:** A high-contrast strip using Tertiary Red, utilizing a "Caution" diagonal stripe pattern (45-degree lines) on the far left edge.