# NetChecker — Prompt de Diseño para Stitch

## Descripción General

Diseña un mockup **profesional y moderno** para **NetChecker**, un sistema de monitoreo y diagnóstico de redes en tiempo real desarrollado para laboratorios académicos. La interfaz debe transmitir que es una herramienta real de administración e infraestructura de red (no un juguete visual), ser intuitiva tanto para estudiantes como para administradores de red, y adaptarse correctamente a **computadores, tablets y dispositivos móviles**.

> **Nota:** todas las métricas mostradas en el mockup son **datos de demostración**; posteriormente serán alimentadas por el backend en **Python/Flask** del proyecto.

---

## Estilo Visual

- **Modo oscuro** como tema principal, estilo tecnológico y limpio.
- Tipografía moderna, sans-serif, orientada a paneles de control (tipo dashboard de NOC/ISP).
- Uso de tarjetas (cards) con bordes sutiles, sombras suaves y buen espaciado.
- **Colores semánticos:**
  - 🟢 **Verde** → funcionamiento normal / ONLINE
  - 🟡 **Amarillo** → advertencia / WARNING
  - 🔴 **Rojo** → falla / OFFLINE
- Iconografía relacionada con redes (señal, servidor, router, globo/DNS, gráficas).

---

## Pantalla Principal: Dashboard de Monitoreo

### 1. Encabezado / Estado General
- Logo y nombre "NetChecker".
- Indicador grande y visible del **estado general de la conexión**: ONLINE / WARNING / OFFLINE (badge con color semántico).
- Fecha/hora de última actualización.

### 2. Tarjetas de Métricas (Cards)
Tarjetas individuales, tipo grid, para:
- **Latencia RTT** (ms)
- **Pérdida de paquetes** (%)
- **Estado del Gateway** (192.168.1.1)
- **Conectividad externa** (8.8.8.8)
- **Resolución DNS** (google.com)

Cada tarjeta debe incluir: ícono representativo, valor actual, estado (color semántico) y una pequeña etiqueta descriptiva.

### 3. Gráficos en Tiempo Real
- Gráfico de línea para **latencia** a lo largo del tiempo.
- Gráfico de línea o barras para **pérdida de paquetes** a lo largo del tiempo.
- Ejes con escala clara, colores acordes al estado (verde/amarillo/rojo).

### 4. Sección de Diagnóstico de Ruta
Representación visual tipo diagrama de flujo horizontal (topología simplificada):

```
Equipo Local → Gateway → Internet → DNS
```

- Cada nodo representado como un ícono/círculo conectado por líneas.
- Color del nodo y de la conexión según su estado (verde = ok, amarillo = advertencia, rojo = falla).
- Al pasar el cursor o tocar cada nodo, mostrar detalle (IP, tiempo de respuesta).

### 5. Tabla de Métricas Actuales
Tabla con columnas como:
- Métrica | Valor actual | Estado | Última verificación

### 6. Sección de Alertas y Eventos Recientes
- Lista tipo timeline/log con eventos recientes (ej. "Pérdida de paquetes detectada", "Gateway restablecido").
- Cada evento con ícono de severidad, marca de tiempo y color semántico.

---

## Responsive / Adaptabilidad

- **Desktop:** layout en grid multi-columna, gráficos grandes, tabla completa visible.
- **Tablet:** grid de 2 columnas, tarjetas apiladas de forma flexible.
- **Móvil:** layout de una sola columna, tarjetas y gráficos apilados verticalmente, diagrama de ruta en formato vertical o con scroll horizontal.

---

## Objetivo del Diseño

Transmitir confiabilidad y precisión técnica, como una herramienta real de diagnóstico de infraestructura de red utilizada en entornos académicos, manteniendo una experiencia clara e intuitiva para usuarios sin necesidad de formación avanzada en redes.
