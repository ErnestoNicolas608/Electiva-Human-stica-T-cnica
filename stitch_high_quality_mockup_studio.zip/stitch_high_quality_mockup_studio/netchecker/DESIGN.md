---
name: NetChecker
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#bcc7de'
  on-secondary: '#263143'
  secondary-container: '#3e495d'
  on-secondary-container: '#aeb9d0'
  tertiary: '#bec6e0'
  on-tertiary: '#283044'
  tertiary-container: '#8990a8'
  on-tertiary-container: '#22293d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
  online: '#4ADE80'
  warning: '#FACC15'
  offline: '#F87171'
  surface-charcoal: '#121826'
  border-subtle: rgba(255, 255, 255, 0.08)
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  data-display:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  card-padding: 20px
  container-max-width: 1440px
---

## Brand & Style
The design system is engineered for **NetChecker**, a professional network monitoring utility for academic environments. The brand personality is technical, reliable, and precise, mirroring the aesthetics of a Network Operations Center (NOC). 

The chosen style is **Corporate / Modern** with a **High-Tech** influence. It prioritizes clarity and data density without sacrificing elegance. The interface utilizes a deep dark-mode palette to reduce eye strain during long monitoring sessions, featuring high-contrast semantic accents that draw immediate attention to system health. Surfaces are defined by subtle depth and crisp outlines rather than heavy skeuomorphism, ensuring the tool feels like a modern piece of infrastructure.

## Colors
The color palette is anchored in a layered dark theme. The base background uses `tertiary_color_hex` (#0F172A), while primary functional cards and containers use `surface-charcoal` (#121826) to create depth. 

**Semantic colors** are the primary drivers of the UI:
- **Online (#4ADE80):** Used for stable connections and healthy metrics.
- **Warning (#FACC15):** Reserved for latency spikes or intermittent packet loss.
- **Offline (#F87171):** High-priority color for downtime or unreachable gateways.

The primary blue (#3B82F6) is used sparingly for interactive elements like buttons or active navigation states to avoid competing with semantic status indicators.

## Typography
The system uses **Inter** for its exceptional legibility in UI contexts and its neutral, professional tone. For numerical data and technical metrics (like IP addresses and RTT values), **JetBrains Mono** is introduced to provide a distinct, monospaced "developer" feel that aids in quick data scanning.

- **Headlines:** Use tighter letter spacing and heavier weights to establish clear hierarchy.
- **Data Display:** Metric values within cards should use the `data-display` style for maximum impact.
- **Labels:** Small uppercase labels are used for metadata and table headers to distinguish them from primary content.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a 12-column structure for desktop. 

- **Desktop (1024px+):** Multi-column dashboard with a fixed sidebar or top navigation. Cards are arranged in a responsive grid (3 or 4 columns for metrics).
- **Tablet (768px - 1023px):** Transition to a 2-column grid for cards. The network topology diagram may require horizontal overflow.
- **Mobile (<768px):** Single-column stack. Metrics are minimized into compact rows or 2x2 grids.

Spacing is governed by a 4px baseline. "Generous spacing" is applied between major sections (24px - 32px) to prevent the data-dense environment from feeling cluttered.

## Elevation & Depth
In this dark-themed environment, depth is achieved through **Tonal Layering** and **Subtle Outlines** rather than heavy shadows.

- **Level 0 (Background):** `tertiary_color_hex` (#0F172A).
- **Level 1 (Cards/Containers):** `surface-charcoal` (#121826) with a 1px border of `border-subtle`.
- **Level 2 (Hover/Active states):** A slightly lighter navy tint or a very soft ambient glow (40% opacity of the semantic color) to indicate focus.

Shadows, when used, are "Ambient Shadows": extremely soft, blurred (16px-24px), and tinted with the background color to appear as a natural light occlusion rather than a floating effect.

## Shapes
The design system utilizes **Rounded** (8px) corners for most UI components. This softens the technical aesthetic, making the dashboard feel modern and accessible.

- **Main Cards:** 12px (`rounded-lg`) to establish container boundaries.
- **Status Badges & Buttons:** 8px (`rounded-md`).
- **Data Points in Charts:** Circular or slightly rounded to maintain consistency with the iconography.
- **Inputs:** 8px to match the button language.

## Components
- **Metric Cards:** Should feature a top-aligned icon, a `label-caps` description, and a large `data-display` value. A small sparkline (mini-chart) should be embedded at the bottom of the card using the relevant semantic color.
- **Status Badges:** Pill-shaped with a solid background of the semantic color at 15% opacity and a high-contrast text color of the same hue. Include a small solid circle icon for "pulse" animation on Online states.
- **Topology Diagram:** Nodes should be represented as 48px circles with centered icons. Connecting lines should be 2px thick, colored according to the downstream node's health.
- **Data Tables:** Row-based with no vertical borders. Use `border-subtle` for horizontal separators. The "Status" column should always use the semantic badge component.
- **Inputs & Search:** Dark filled fields with a subtle border. On focus, the border transitions to `primary_color_hex` with a soft blue outer glow.
- **Timeline/Logs:** Left-aligned vertical line with dots corresponding to event timestamps. Use semantic colors for the dots to categorize the severity of the log entry.