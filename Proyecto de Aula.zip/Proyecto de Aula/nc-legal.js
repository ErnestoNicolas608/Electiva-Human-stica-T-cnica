/* ==========================================================================
   NetChecker · Privacidad y tratamiento de datos (Ley 1581 de 2012, Colombia)
   1) Banner de consentimiento de cookies (primera visita).
   2) Casilla de consentimiento obligatoria en formularios con datos personales.
   Sin dependencias. Se carga igual en el sitio principal y en la política.

   Para activar analítica en el futuro, solo hay que cargarla si el usuario aceptó:
     if (window.NCConsent.analyticsAllowed()) { ...cargar script de analítica... }
     window.addEventListener('nc:consent', function (e) { if (e.detail.analytics) { ... } });
   ========================================================================== */
(function () {
  'use strict';

  var POLICY_URL = 'politica-de-privacidad.html';
  var KEY = 'nc-cookie-consent';
  var MAX_AGE_MS = 365 * 24 * 60 * 60 * 1000;   // se vuelve a preguntar cada 12 meses
  var memory = null;                             // respaldo si el navegador bloquea localStorage

  /* ------------------------------------------------ preferencia guardada */
  function read() {
    var raw = null;
    try { raw = window.localStorage.getItem(KEY); } catch (e) { return memory; }
    if (!raw) return memory;
    try {
      var o = JSON.parse(raw);
      if (!o || typeof o.ts !== 'number' || typeof o.analytics !== 'boolean') return null;
      if (Date.now() - o.ts > MAX_AGE_MS) return null;
      return o;
    } catch (e) { return null; }
  }

  function save(analytics) {
    var o = { v: 1, essential: true, analytics: !!analytics, ts: Date.now() };
    memory = o;
    try { window.localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) { /* sin almacenamiento: queda en memoria */ }
    try { window.dispatchEvent(new CustomEvent('nc:consent', { detail: o })); } catch (e) { /* navegadores antiguos */ }
    return o;
  }

  /* ------------------------------------------------ banner de cookies */
  var banner = null;
  var opener = null;

  function build() {
    if (banner) return banner;
    banner = document.createElement('div');
    banner.className = 'nc-cookie';
    banner.id = 'ncCookie';
    banner.setAttribute('role', 'dialog');
    banner.setAttribute('aria-labelledby', 'ncCookieTitle');
    banner.setAttribute('aria-describedby', 'ncCookieText');
    banner.hidden = true;
    banner.innerHTML =
      '<div class="nc-cookie-body">' +
        '<p class="nc-cookie-title" id="ncCookieTitle">Tu privacidad</p>' +
        '<p class="nc-cookie-text" id="ncCookieText">Usamos almacenamiento esencial para que el sitio funcione y, solo si lo aceptas, ' +
        'cookies analíticas para mejorarlo. Puedes cambiar tu decisión cuando quieras. Más información en la ' +
        '<a href="' + POLICY_URL + '#cookies">Política de Tratamiento de Datos</a>.</p>' +
      '</div>' +
      '<div class="nc-cookie-actions">' +
        '<button type="button" class="btn-secondary" id="ncCookieReject">Rechazar no esenciales</button>' +
        '<button type="button" class="btn-primary" id="ncCookieAccept">Aceptar todas</button>' +
      '</div>';
    document.body.appendChild(banner);
    banner.querySelector('#ncCookieAccept').addEventListener('click', function () { decide(true); });
    banner.querySelector('#ncCookieReject').addEventListener('click', function () { decide(false); });
    return banner;
  }

  function show(focus) {
    build().hidden = false;
    if (focus) banner.querySelector('#ncCookieAccept').focus({ preventScroll: true });
  }

  function hide() { if (banner) banner.hidden = true; }

  function decide(analytics) {
    save(analytics);
    hide();
    if (opener && opener.focus) { opener.focus({ preventScroll: true }); }
    opener = null;
  }

  function initBanner() {
    if (!read()) { setTimeout(function () { if (!read()) show(false); }, 600); }
    document.addEventListener('click', function (ev) {
      var t = ev.target.closest ? ev.target.closest('[data-nc-cookie-settings]') : null;
      if (!t) return;
      ev.preventDefault();
      opener = t;
      show(true);
    });
  }

  window.NCConsent = {
    get: read,
    analyticsAllowed: function () { var o = read(); return !!(o && o.analytics); },
    open: function () { show(true); }
  };

  /* ------------------------------------------------ consentimiento en formularios */
  var PERSONAL = [
    'input[type="email"]', 'input[type="tel"]',
    'input[autocomplete="name"]', 'input[autocomplete="email"]', 'input[autocomplete="tel"]',
    'input[name*="nombre" i]', 'input[name*="name" i]', 'input[name*="correo" i]',
    'input[name*="email" i]', 'input[name*="telefono" i]', 'input[name*="celular" i]', 'input[name*="phone" i]'
  ].join(',');

  var uid = 0;

  function submitControls(form) {
    return Array.prototype.slice.call(form.querySelectorAll('button[type="submit"], input[type="submit"], button:not([type])'));
  }

  function enhance(form) {
    if (form.hasAttribute('data-nc-no-consent') || form.querySelector('.nc-consent')) return;
    if (!form.querySelector(PERSONAL)) return;

    var id = 'ncConsent' + (++uid);
    var label = document.createElement('label');
    label.className = 'nc-consent';
    label.setAttribute('for', id);
    label.innerHTML =
      '<input type="checkbox" id="' + id + '" name="nc_consentimiento" required>' +
      '<span>He leído y acepto la <a href="' + POLICY_URL + '" target="_blank" rel="noopener">Política de Tratamiento de Datos</a> ' +
      'y autorizo el uso de mis datos personales.</span>';

    var controls = submitControls(form);
    if (controls.length) {
      // Se coloca justo antes del bloque (hijo directo del formulario) que contiene el botón de envío
      var n = controls[0];
      while (n.parentNode && n.parentNode !== form) { n = n.parentNode; }
      if (n.parentNode === form) { form.insertBefore(label, n); } else { form.appendChild(label); }
    } else {
      form.appendChild(label);
    }

    var box = label.querySelector('input');
    function sync() {
      controls.forEach(function (c) {
        c.disabled = !box.checked;
        c.setAttribute('aria-disabled', String(!box.checked));
      });
    }
    box.addEventListener('change', sync);
    sync();

    // Segunda barrera: aunque se fuerce el envío (Enter, script), no sale sin consentimiento
    form.addEventListener('submit', function (ev) {
      if (!box.checked) {
        ev.preventDefault();
        ev.stopImmediatePropagation();
        box.focus();
        if (box.reportValidity) box.reportValidity();
      }
    }, true);
  }

  function scanForms(root) {
    var forms = root.querySelectorAll ? root.querySelectorAll('form') : [];
    Array.prototype.forEach.call(forms, enhance);
    if (root.tagName === 'FORM') enhance(root);
  }

  function initForms() {
    scanForms(document);
    if (!window.MutationObserver) return;
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        Array.prototype.forEach.call(m.addedNodes, function (n) { if (n.nodeType === 1) scanForms(n); });
      });
    }).observe(document.body, { childList: true, subtree: true });
  }

  /* ------------------------------------------------ arranque */
  function init() { initBanner(); initForms(); }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); }
  else { init(); }
})();
